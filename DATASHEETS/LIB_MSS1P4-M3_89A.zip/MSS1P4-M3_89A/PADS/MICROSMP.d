*PADS-LIBRARY-PCB-DECALS-V9*

MICROSMP         M -6.313 -0.705 0 2 2 0 2 2 0
TIMESTAMP 2017.09.18.09.45.53
-0.93 1.214 0     0 0.381 0.0381 1 0 34 "Regular <Romansim Stroke Font>"
REF-DES
-0.93 1.214 0     0 0.381 0.0381 1 32 35 "Regular <Romansim Stroke Font>"
PART-TYPE
CLOSED 5 0.2 27 -1
-1.1  0.65 
1.1   0.65 
1.1   -0.65
-1.1  -0.65
-1.1  0.65 
CIRCLE 2 0.2 26 -1
-1.85 0.026
-1.812 0.026
T-0.65 0     -0.65 0     1
T1.25  0     1.25  0     2
PAD 0 3 N 0    
-2 0.8 S   0  
-1 0   R  
0  0   R  
PAD 1 3 N 0    
-2 1.1 RF  0   0    2  0  
-1 0   R  
0  0   R
*END*
*REMARK* AP
MSS1P4-M3_89A.stp/90/0/0/0.5199999809265137/0.20999999344348907/0.09000000357627869
